package org.dyn4j.dynamics.joint;

import org.dyn4j.Epsilon;
import org.dyn4j.dynamics.Body;
import org.dyn4j.dynamics.Settings;
import org.dyn4j.dynamics.Step;
import org.dyn4j.geometry.Geometry;
import org.dyn4j.geometry.Mass;
import org.dyn4j.geometry.Transform;
import org.dyn4j.geometry.Vector2;
import org.dyn4j.resources.Messages;

public class SpringJoint extends Joint {
	/** The local anchor point on the first {@link Body} */
	protected Vector2 localAnchor1;
	
	/** The local anchor point on the second {@link Body} */
	protected Vector2 localAnchor2;
	
	/**Spring constant in N/m2*/
	private double springConstant =500;
	
	/** The damping ratio */
	protected double dampingCoeff;
	
	/** The Natural Length of spring (computed distance between the two world space anchor points) */
	protected double naturalLength;
	
	/** The normal */
	protected Vector2 n;
	
	/** The accumulated impulse from the previous time step */
	protected double impulse;
	
	/** The effective mass of the two body system (Reduced mass translational+Rotational) */
	protected double invEqMass;
	
	/** The oscillation frequency in hz */
	protected double frequency;

	/** if the Spring is harmonic oscillator (keeps frequency constant)*/
	protected boolean oscillator=false;
	
	/**
	 * Minimal constructor.
	 * <p>
	 * Creates a fixed distance {@link Joint} where the joined 
	 * {@link Body}s do not participate in collision detection and
	 * resolution.
	 * @param body1 the first {@link Body}
	 * @param body2 the second {@link Body}
	 * @param anchor1 in world coordinates
	 * @param anchor2 in world coordinates
	 * @param k spring constant
	 * @param damping Coefficient
	 * @throws NullPointerException if body1, body2, anchor1, or anchor2 is null
	 * @throws IllegalArgumentException if body1 == body2, k<=0, dampingCoeff<0;
	 */
	public SpringJoint(Body body1, Body body2, Vector2 anchor1, Vector2 anchor2, double k,double dampingCoeff) {
		super(body1, body2, false);
		// verify the bodies are not the same instance
		if (body1 == body2) throw new IllegalArgumentException(Messages.getString("dynamics.joint.sameBody"));
		// verify the anchor points are not null
		if (anchor1 == null) throw new NullPointerException(Messages.getString("dynamics.joint.nullAnchor1"));
		if (anchor2 == null) throw new NullPointerException(Messages.getString("dynamics.joint.nullAnchor2"));
		// get the local anchor points
		this.localAnchor1 = body1.getLocalPoint(anchor1);
		this.localAnchor2 = body2.getLocalPoint(anchor2);
		if(k<=0)throw new IllegalArgumentException("ForceConstant can not be less than or equal to zero");
		if(dampingCoeff<0)throw new IllegalArgumentException("DampingCoeff can not be less than zero");
		this.springConstant=k;
		this.dampingCoeff=dampingCoeff;
		// compute the initial distance
		this.naturalLength = anchor1.distance(anchor2);
		this.n = new Vector2();
		
		//compute effective inverseMass
		Transform t1 = body1.getTransform();
		Transform t2 = body2.getTransform();
		Mass m1 = body1.getMass();
		Mass m2 = body2.getMass();
		
		double invM1 = m1.getInverseMass();
		double invM2 = m2.getInverseMass();
		double invI1 = m1.getInverseInertia();
		double invI2 = m2.getInverseInertia();
		
		// compute the normal
		Vector2 r1 = t1.getTransformedR(this.body1.getLocalCenter().to(this.localAnchor1));
		Vector2 r2 = t2.getTransformedR(this.body2.getLocalCenter().to(this.localAnchor2));
		this.n = r1.sum(this.body1.getWorldCenter()).subtract(r2.sum(this.body2.getWorldCenter()));
		
		// compute effective mass
		double cr1n = r1.cross(this.n);
		double cr2n = r2.cross(this.n);
		double invMass = invM1 + invI1 * cr1n * cr1n;
		invMass += invM2 + invI2 * cr2n * cr2n;
		
		// check for zero before inverting
		this.invEqMass = invMass <= Epsilon.E ? 0.0 : 1.0 / invMass;

	}
	
	/*
	 * @see org.dyn4j.dynamics.joint.Joint#toString()
	 */
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("SpringJoint[").append(super.toString())
		.append("|LocalAnchor1=").append(this.localAnchor1)
		.append("|LocalAnchor2=").append(this.localAnchor2)
		.append("|WorldAnchor1=").append(this.getAnchor1())
		.append("|WorldAnchor2=").append(this.getAnchor2())
		.append("|springConstant=").append(this.springConstant)
		.append("|DampingRatio=").append(this.dampingCoeff)
		.append("]");
		return sb.toString();
	}
	
	
	/* (non-Javadoc)
	 * @see org.dyn4j.dynamics.joint.Joint#initializeConstraints()
	 */
	@Override
	public void initializeConstraints(Step step, Settings settings) {
		
		double linearTolerance = settings.getLinearTolerance();
		
		Transform t1 = body1.getTransform();
		Transform t2 = body2.getTransform();
		Mass m1 = body1.getMass();
		Mass m2 = body2.getMass();
		
		double invM1 = m1.getInverseMass();
		double invM2 = m2.getInverseMass();
		double invI1 = m1.getInverseInertia();
		double invI2 = m2.getInverseInertia();
		
		// compute the normal
		Vector2 r1 = t1.getTransformedR(this.body1.getLocalCenter().to(this.localAnchor1));
		Vector2 r2 = t2.getTransformedR(this.body2.getLocalCenter().to(this.localAnchor2));
		this.n = r1.sum(this.body1.getWorldCenter()).subtract(r2.sum(this.body2.getWorldCenter()));
		
		// compute effective mass
		double cr1n = r1.cross(this.n);
		double cr2n = r2.cross(this.n);
		double invMass = invM1 + invI1 * cr1n * cr1n;
		invMass += invM2 + invI2 * cr2n * cr2n;
		
		// check for zero before inverting
		this.invEqMass = invMass <= Epsilon.E ? 0.0 : 1.0 / invMass;

		//Temporary value of force constant k
		double k;
		if (oscillator){
			// compute the natural frequency; f = w / (2 * pi) -> w = 2 * pi * f
			double w = Geometry.TWO_PI * this.frequency;
			// check for zero before inverting
			double massEff= invMass <= Epsilon.E ? 0.0 : 1.0 / invMass;
			k = massEff * w * w;
		}else{
			k=this.springConstant;
			this.frequency= Math.sqrt(this.springConstant*this.invEqMass)/(2*Math.PI);
		}
			
		// get the current length
		double length = this.n.getMagnitude();
		// check for the tolerance
		if (length < linearTolerance) {
			this.n.zero();
		} else {
			// normalize it
			this.n.multiply(1.0 / length);
		}
		double dt = step.getDeltaTime();
		// get the current compression/extension of the spring
		double x = length - this.naturalLength;
		
		// compute the speeds of anchor points of spring (v=v0+rw)
		Vector2 v1 = body1.getLinearVelocity().sum(r1.cross(body1.getAngularVelocity()));
		Vector2 v2 = body2.getLinearVelocity().sum(r2.cross(body2.getAngularVelocity()));
				
		// compute relative speed of anchor points of spring(rate of change of length of spring)
		double rv = n.dot(v1.difference(v2));
		
		//use force =-kx-bv
		this.impulse=-k*x*dt-dampingCoeff*rv*dt;
				
		Vector2 J = n.product(impulse);
		/*
		if(body1.isColliding){
			J=J.difference(body1.collisionN.product(J.dot(body1.collisionN)));
		}
		*/
		body1.getLinearVelocity().add(J.product(invM1));
		body1.setAngularVelocity(body1.getAngularVelocity() + invI1 * r1.cross(J));
		J = n.product(impulse);
		/*
		if(body2.isColliding){
			J=J.difference(body2.collisionN.product(J.dot(body2.collisionN)));
		}
		*/
		body2.getLinearVelocity().subtract(J.product(invM2));
		body2.setAngularVelocity(body2.getAngularVelocity() - invI2 * r2.cross(J));
		
	}
	
	/* (non-Javadoc)
	 * @see org.dyn4j.dynamics.joint.Joint#solveVelocityConstraints()
	 */
	@Override
	public void solveVelocityConstraints(Step step, Settings settings) {
		
	}
	
	@Override
	public boolean solvePositionConstraints(Step step, Settings settings) {
		double linearTolerance = settings.getLinearTolerance();
		
		Transform t1 = body1.getTransform();
		Transform t2 = body2.getTransform();

		// compute the normal
		Vector2 r1 = t1.getTransformedR(this.body1.getLocalCenter().to(this.localAnchor1));
		Vector2 r2 = t2.getTransformedR(this.body2.getLocalCenter().to(this.localAnchor2));
		this.n = r1.sum(this.body1.getWorldCenter()).subtract(r2.sum(this.body2.getWorldCenter()));
		// get the current length
		double length = this.n.getMagnitude();
		// check for the tolerance
		if (length < linearTolerance) {
			this.n.zero();
		} else {
			// normalize it
			this.n.multiply(1.0 / length);
		}
		double dt = step.getDeltaTime();
		// get the current compression/extension of the spring
		double x = length - this.naturalLength;
		
		
		// compute the speeds of anchor points of spring (v=v0+rw)
		Vector2 v1 = body1.getLinearVelocity().sum(r1.cross(body1.getAngularVelocity()));
		Vector2 v2 = body2.getLinearVelocity().sum(r2.cross(body2.getAngularVelocity()));
				
		// compute relative speed of anchor points of spring(rate of change of length of spring)
		double rv = n.dot(v1.difference(v2));
		
		//use force =-kx-bv
		this.impulse=-springConstant*x*dt-dampingCoeff*rv*dt;

		// don't solve position constraints for spring damper
		return true;
	}

	/* (non-Javadoc)
	 * @see org.dyn4j.dynamics.joint.Joint#getReactionForce(double)
	 */
	@Override
	public Vector2 getReactionForce(double invdt) {
		return this.n.product(this.impulse * invdt);
	}
	
	/**
	 * {@inheritDoc}
	 * <p>
	 * Not applicable to this joint. Always returns zero.
	 */
	@Override
	public double getReactionTorque(double invdt) {
		return 0.0;
	}
	
	/**
	 * Returns true if this distance joint is a spring distance joint
	 * with damping.
	 * @return boolean
	 */
	public boolean isSpringDamper() {
		return this.dampingCoeff > 0.0;
	}
	
	/**
	 * Returns the damping ratio.
	 * @return double
	 */
	public double getDampingcoeff() {
		return this.dampingCoeff;
	}
	
	/**
	 * Sets the damping ratio.
	 * @param dampingRatio the damping ratio; in the range [0, 1]
	 * @throws IllegalArgumentException if damping ration is less than zero or greater than 1
	 */
	public void setDampingCoeff(double dampingCoeff) {
		// make sure its within range
		if (dampingCoeff < 0 ) throw new IllegalArgumentException("DampingCoeff can not be less than to zero");
		// set the new value
		this.dampingCoeff = dampingCoeff;
	}
	
	/**
	 * Returns the spring frequency.
	 * @return double
	 */
	public double getFrequency() {
		if (oscillator){
			return this.frequency;
		}else{
			return Math.sqrt(this.springConstant*this.invEqMass)/(2*Math.PI);
		}
	}
	
	/**
	 * Sets the spring frequency.
	 * @param frequency the spring frequency in hz; must be greater than or equal to zero
	 * @throws IllegalArgumentException if frequency is less than zero
	 */
	public void setFrequency(double frequency) {
		// check for valid value
		if (frequency < 0) throw new IllegalArgumentException("frequency can not be less than or equal to zero");
		// set the new value
		this.frequency = frequency;
	}

	/**
	 * Returns the rest distance between the two constrained {@link Body}s in meters.
	 * @return double
	 */
	public double getNaturalLength() {
		return this.naturalLength;
	}
	
	/**
	 * Sets the rest distance between the two constrained {@link Body}s in meters.
	 * @param naturalLength the naturalLength in meters
	 * @throws IllegalArgumentException if distance is less than zero
	 */
	public void setNaturalLength(double naturalLength) {
		// make sure the distance is greater than zero
		if (naturalLength < 0.0) throw new IllegalArgumentException("Natural Length can not be less than zero");
		// wake up both bodies
		this.body1.setAsleep(false);
		this.body2.setAsleep(false);
		// set the new target distance
		this.naturalLength = naturalLength;
	}

	/**
	 * Sets Spring Constant of the spring
	 * @param springConstant
	 */
	public void setSpringConstant(double springConstant){
		// make sure springConstant is greater than zero
		if (springConstant < 0.0) throw new IllegalArgumentException("ForceConstant can not be less than or equal to zero");
		this.springConstant=springConstant;
	}

	/**
	 * returns Spring Constant of the Spring
	 * @return Spring Constant of the Spring
	 */
	public double getSpringConstant(){
		return this.springConstant;
	}
	
	/* (non-Javadoc)
	 * @see org.dyn4j.dynamics.joint.Joint#getAnchor1()
	 */
	public Vector2 getAnchor1() {
		return body1.getWorldPoint(this.localAnchor1);
	}
	
	/* (non-Javadoc)
	 * @see org.dyn4j.dynamics.joint.Joint#getAnchor2()
	 */
	public Vector2 getAnchor2() {
		return body2.getWorldPoint(this.localAnchor2);
	}

	/**
	 * Translates local anchor Point of Joint on first body (experimental) 
	 * @param vt Translation vector
	 */
	public  void translateLocalAnchor1(Vector2 vt) {
		this.localAnchor1.add(vt);
	}
	
	
	/**
	 * Translates local anchor Point of Joint on second body (experimental) 
	 * @param vt Translation vector
	 */
	public  void translateLocalAnchor2(Vector2 vt) {
		this.localAnchor2.add(vt);
		
	}
	
	@Override
	public void shift(Vector2 shift) {
		// nothing to translate here since the anchor points are in local coordinates
		// they will move with the bodies
	}
}
